/*Assignment A12
CST8221_JAP_S22
Christopher Decarie-Dawson
Student#:040718315
Date:2022/10/02
Verison: 1.2
*/


import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;


public class NumGam implements ActionListener {



    /* Dimension of the Board */
    protected static int DIM =9;  // For N * N board DIM = N
    /* Total number of cells in the board */
    protected static final int SIZE = DIM * DIM;
    /* Win state */
    final String[] WIN = new String[SIZE-1];
    /* Initial Height of the board*/
    private static final int HEIGHT = 800;
    /* Initial Width of the board*/
    private static final int WIDTH = 800;
    /* Initial empty cell in the board*/
    private int emptyCell = DIM * DIM;

    int[]arr ={3, 5, 9};


    protected JButton[][] board = new JButton[DIM][DIM];



    private final JPanel panel = new JPanel();

    private final JPanel logo = new JPanel();
    private final JLabel jLabel = new JLabel();
    private final JPanel Options = new JPanel();
    private JButton ResetButton;

    private final JLabel timer = new JLabel();

    private JComboBox dims;


    // Suppresses default constructor, ensuring non-instantiability.
    public NumGam() {

        // Initialize the win state
        for (int i = 1; i < SIZE; i++) {
            WIN[i-1] = Integer.toString(i);
        }

        System.out.println("Win State:" + Arrays.asList(WIN) );
    }

    public static void main(String[] args) throws IOException {
        NumGam game = new NumGam();
        game.initializeBoard();
    }



    /**
     * Gives index value corresponding to [row,col] of a square
     * @param i, row
     * @param j, column
     * @return the index of the corresponding to the row and column
     */
    private int getIndex(int i, int j) {
        return ((i * DIM) + j);  // i * Dim + j

    }

    /**
     * Generates the random initial state for the game.
     * Assigns unique random number to each square
     */
    private void initializeBoard() throws IOException {
        ArrayList<Integer> intialList = new ArrayList<Integer>(SIZE);

        // Repeat until creation of solvable initial board
        for (boolean isSolvable = false; !isSolvable; ) {

            // create ordered list
            intialList = new ArrayList<Integer>(SIZE);
            for (int i = 0; i < SIZE; i++) {
                intialList.add(i, i);
            }

            // Shuffle the list
            Collections.shuffle(intialList);

            // Check list can be solvable or not
            isSolvable = isSolvable(intialList);
        }
        System.out.println("Initial Board state:" + intialList);

        // Assigns unique random number to each square
        for (int index = 0; index < SIZE; index++) {
            final int ROW = index / DIM;  // row number from index
            final int COL = index % DIM;   // column number from index
            board[ROW][COL] = new JButton(String.valueOf(intialList.get(index)));
            // Initializes the empty square and hide it
            if (intialList.get(index) == 0) {
                emptyCell = index;
                board[ROW][COL].setVisible(false);
            }

            // Decorating each square
            board[ROW][COL].setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            board[ROW][COL].setBackground(Color.BLACK);
            board[ROW][COL].setForeground(Color.WHITE);
            board[ROW][COL].addActionListener(this);
            panel.add(board[ROW][COL]);
        }

        // Initializes the Frame
        JFrame frame = new JFrame("NumGam");
        frame.setLocation(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(HEIGHT, WIDTH);


        // Initializes the Main grid panel.
        panel.setLayout(new GridLayout(DIM, DIM));
        panel.setBackground(Color.GRAY);

        // initializes the Logo at the top.
        File file =new File("C:\\Users\\melsa\\IdeaProjects\\NumGam\\images\\logo.jpeg");
        BufferedImage BufferedIamge = ImageIO.read(file);
        ImageIcon imageIcon = new ImageIcon(BufferedIamge);
        jLabel.setIcon(imageIcon);
        logo.add(jLabel);
        logo.setName("NumGam");
        logo.setPreferredSize( new Dimension(500,93));
        logo.setBackground(Color.LIGHT_GRAY);
        logo.setOpaque(true);

        // initializes the Options zone of the game.
        Options.setLayout(new GridBagLayout());
        GridBagConstraints gbc;
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
       // dims.addItem("3x3");
       // dims.addItem("5x5");
       // dims.addItem("9x9");

        JComboBox<Integer> dims = new JComboBox<Integer>();
        dims.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if(e.getStateChange()==ItemEvent.SELECTED)
                    dims.getItemAt(ItemEvent.SELECTED);

                    }
                }
            );
        Options.add(dims);



        //Place holder for New game button.
        ResetButton = new JButton();
        ResetButton.setBackground(Color.orange);
        ResetButton.setText("New Game");
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        Options.add(ResetButton,gbc);
        Options.setPreferredSize(new Dimension(400,600));
        Options.setBackground(Color.DARK_GRAY);




        // Initializes the content pane
        Container content = frame.getContentPane();
        content = frame.getContentPane();
        content.add(logo, BorderLayout.NORTH);
        content.add(panel, BorderLayout.WEST);
        content.add(Options,BorderLayout.EAST);
        content.setBackground(Color.GRAY);
        frame.setVisible(true);
    }



    /**
     * Verifies the board for solvability.
     * @param list,  elements from 0-81 no repetition of elements
     * @return true, if the initial board can be solvable
     *         false, if the initial board can't be solvable
     */
    private boolean isSolvable(ArrayList<Integer> list) {



        int inversionSum = 0;  // If this sum is even it is solvable
        for (int i = 0; i < list.size(); i++) {
            // For empty square add row number to inversionSum
            if (list.get(i) == 0) {
                inversionSum += ((i / DIM) + 1);  //add Row number
                continue;
            }

            int count = 0;
            for (int j = i + 1; j < list.size(); j++) {
                // No need need to count for empty square
                if (list.get(j) == 0) {
                    continue;
                } else if (list.get(i) > list.get(j)) { // If any element greater
                    count++;                            // than seed increase the
                }                                       // inversionSum
            }
            inversionSum += count;
        }

        // if inversionSum is even return true, otherwise false
        return (inversionSum & 1) == 0;
    }

    /**
     * If any button in the board is pressed, it will perform the
     * required actions associated with the button. Actions like
     * checking isAdjacent(), swapping using swapWithEmpty() and also
     * checks to see whether the game is finished or not.
     *
     * @param event, event performed by the player
     * @throws IllegalArgumentException, if the <tt>index = -1 </tt>
     */
    public void actionPerformed(ActionEvent event) throws IllegalArgumentException {
        JButton buttonPressed = (JButton) event.getSource();
        int index = indexOf(buttonPressed.getText());
        if (index == -1) {
            throw (new IllegalArgumentException("Index should be between 0-81"));
        }
        int row = index / DIM;
        int column = index % DIM;

        // If pressed button in same row or same column
        makeMove(row, column);

        // If the game is finished, "You Win the Game" dialog will appear
        if (isFinished()) {
            JOptionPane.showMessageDialog(null, "You Win The Game.");
        }
    }

    /**
     * Gives the index by processing the text on square
     * @param cellNum, number on the button
     * @return the index of the button
     */
    private int indexOf(String cellNum) {

        for (int ROW = 0; ROW < board.length; ROW++) {
            for (int COL = 0; COL < board[ROW].length; COL++) {
                if (board[ROW][COL].getText().equals(cellNum)) {
                    return (getIndex(ROW, COL));
                }
            }
        }
        return -1;   // Wrong input returns -1

    }

    /**
     * Checks the row or column with empty square
     * @return true, if we pressed the button in same row or column
     *              as empty square
     *         false, otherwise
     */
    private boolean makeMove(int row, int col) {
        final int emptyRow = emptyCell / DIM;  // Empty cell row number
        final int emptyCol = emptyCell % DIM;   // Empty cell column number
        int rowDiff = emptyRow - row;
        int colDiff = emptyCol - col;
        boolean isInRow = (row == emptyRow);
        boolean isInCol = (col == emptyCol);
        boolean isNotDiagonal = (isInRow || isInCol);

        if (isNotDiagonal) {
            int diff = Math.abs(colDiff);

            // -ve diff, move row left
            if (colDiff < 0 & isInRow) {
                for (int i = 0; i < diff; i++) {
                    board[emptyRow][emptyCol + i].setText(
                            board[emptyRow][emptyCol + (i + 1)].getText());
                }

            } // + ve Diff, move row right
            else if (colDiff > 0 & isInRow) {
                for (int i = 0; i < diff; i++) {
                    board[emptyRow][emptyCol - i].setText(
                            board[emptyRow][emptyCol - (i + 1)].getText());
                }
            }

            diff = Math.abs(rowDiff);

            // -ve diff, move column up
            if (rowDiff < 0 & isInCol) {
                for (int i = 0; i < diff; i++) {
                    board[emptyRow + i][emptyCol].setText(
                            board[emptyRow + (i + 1)][emptyCol].getText());
                }

            } // + ve Diff, move column down
            else if (rowDiff > 0 & isInCol) {
                for (int i = 0; i < diff; i++) {
                    board[emptyRow - i][emptyCol].setText(
                            board[emptyRow - (i + 1)][emptyCol].getText());
                }
            }

            // Swap the empty square with the given square
            board[emptyRow][emptyCol].setVisible(true);
            board[row][col].setText(Integer.toString(0));
            board[row][col].setVisible(false);
            emptyCell = getIndex(row, col);
        }

        return true;
    }






    /**
     * Checks where game is finished or not
     * @return true, if the board is in final state
     *         false, if the board is not in final state
     */
    private boolean isFinished() {
        // Check elements whether they are in right position or not
        for (int index = WIN.length - 1; index >= 0; index--) {
            String number = board[index / DIM][index % DIM].getText();
            if (!number.equals(WIN[index])) {
                return false;       // If any of the index is not aligned

            }
        }
        return true;
    }
}